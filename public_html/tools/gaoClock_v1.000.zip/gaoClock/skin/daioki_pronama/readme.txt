このスキンでは、大沖さん(公式サイト：http://daioki.tumblr.com/)のイラストを使用しています。

このスキンに利用したプロ生ちゃん（暮井 慧）の画像は
こちらのサイトの利用ガイドラインに従って利用しています。
http://pronama.azurewebsites.net/pronama/guideline/

これら画像を当作品以外で利用することはご遠慮ください。

http://pronama.jp/
copyright 2011 プログラミング生放送



その他何かスキンに関して不具合や質問があれば、Twitterアカウント「@gaogao_9」まで。
名前　　　：がお
アカウント：https://twitter.com/gaogao_9
公開日　　：14/12/10
最終更新日：14/12/10
