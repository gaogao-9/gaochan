﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Collections;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;

namespace ProcessAkkarin
{
    public struct ProcessInfo
    {
        public IntPtr id;
        public string title;
        public int crKey;
        public byte alpha;
        public int dwFlag;
    }

    public partial class MainForm : Form
    {
        //** グローバルな変数関連 **//
        private bool hideFlag { set; get; }
        private int akariRate { set; get; }
        private ArrayList allProcessList { set; get; }
        private ArrayList akariProcessList { set; get; }
        //** グローバルな変数関連ここまで **//

        //** メインルーチン&初期化 **//
        public MainForm()
        {
            InitializeComponent();
            this.Init();

            ReloadAllProcessArray(); //配列データの更新
            ReloadAllProcessList(); //表示してるリストの更新
        }
        public void Init()
        {
            allProcessList   = new ArrayList();
            akariProcessList = new ArrayList();
            notifyIcon.ContextMenuStrip = contextMenuStrip1;
        }
        //** メインルーチン&初期化ここまで **//

        //** 色んな機能を詰め込んだもの **//
        public void ReloadAllProcessArray() //全プロセスを取得して、配列に記憶する関数
        {
            ProcessInfo tempInfo = new ProcessInfo();
            allProcessList.Clear(); //空っぽにする
            Win32API.EnumWindows(new Win32API.EnumWindowsDelegate(delegate(IntPtr hWnd, int lParam)
            {
                StringBuilder sb = new StringBuilder(0x1024);
                if (Win32API.IsWindowVisible(hWnd) != 0 && Win32API.GetWindowText(hWnd, sb, sb.Capacity) != 0)
                {
                    string title = sb.ToString();
                    int pid;
                    Win32API.GetWindowThreadProcessId(hWnd, out pid);
                    Process p = Process.GetProcessById(pid);

                    if (hWnd != this.Handle) //プロセス＼ｱｯｶﾘｰﾝ／は検索外にする。
                    {
                        tempInfo.id = hWnd;
                        tempInfo.title = title;
                        allProcessList.Add(tempInfo);
                    }
                }
                return 1;
            }), 0);
        }

        public void ReloadAllProcessList() //全プロセスをリストアイテムに反映する。
        {
            AllProcessListBox.Items.Clear(); //からっぽにする

            ProcessInfo tempInfo = new ProcessInfo();
            for (int i = 0, iLen = allProcessList.Count; i < iLen; ++i)
            {
                tempInfo = (ProcessInfo)allProcessList[i];
                AllProcessListBox.Items.Add(tempInfo.title);
            }
        }

        public void ReloadAkariProcessArray()
        {
            ArrayList beforeAkariList = (ArrayList)akariProcessList.Clone(); //コピーしといてから
            akariProcessList.Clear(); //空っぽに。

            ProcessInfo tempInfo;
            string tempText;
            ReloadAllProcessArray();
            for (int i = 0, iLen = AkariListBox.Items.Count; i < iLen; ++i)
            {
                tempText = AkariListBox.Items[i].ToString();
                for (int j = 0, jLen = allProcessList.Count; j < jLen; ++j)
                {
                    tempInfo = (ProcessInfo)allProcessList[j];
                    if (tempInfo.title.IndexOf(tempText) > -1)
                    {
                        akariProcessList.Add(tempInfo);
                    }

                }
            }

            /// リネーム等で行方を失ったハンドルの透明度を戻すためのチェックを入れる。
            ProcessInfo temp1,temp2;
            bool res;
            for(int i=0,iLen=beforeAkariList.Count;i<iLen;++i)
            {
                res = false;
                temp1 = (ProcessInfo)beforeAkariList[i];
                for(int j=0,jLen=akariProcessList.Count;j<jLen;++j)
                {
                    temp2 = (ProcessInfo)akariProcessList[j];
                    if (temp1.id == temp2.id)
                    {
                        res = true;
                        break;
                    }
                }
                if (!res)
                {
                    ChangeDefaultAlphaAt(temp1.id); //次回の透過対象に入っていないハンドルは強制的に普通なものに。
                }
            }
        }

        public void ChangeAlpha(bool mode = true)
        {
            IntPtr activeHWnd = Win32API.GetForegroundWindow();
            ProcessInfo tempInfo = new ProcessInfo();
            for(int i=0,iLen=akariProcessList.Count;i<iLen;++i)
            {
                byte alpha = (byte)((100-akariRate) * 255/100);
                tempInfo = (ProcessInfo)akariProcessList[i];
                if (tempInfo.id == this.Handle) //自分自身だったらｽﾙｰ
                {
                    continue;
                }
                bool res = Win32API.GetLayeredWindowAttributes(tempInfo.id,out tempInfo.crKey,out tempInfo.alpha,out tempInfo.dwFlag);
                if (mode && (tempInfo.id!=activeHWnd))
                {
                    if (tempInfo.dwFlag != 2)
                    {
                        Win32API.SetWindowLong(tempInfo.id, Win32API.GWL_EXSTYLE, Win32API.WS_EX_LAYERED);
                    }
                    if (tempInfo.alpha != alpha)
                    {
                        Win32API.SetLayeredWindowAttributes(tempInfo.id, 0, alpha, 2);
                    }
                }
                else
                {
                    if (tempInfo.dwFlag != 0)
                    {
                        Win32API.SetWindowLong(tempInfo.id, Win32API.GWL_EXSTYLE, Win32API.WS_EX_NORMAL);
                    }
                }
            }
        }

        public void ChangeDefaultAlphaAt(IntPtr hWnd)
        {
            Win32API.SetWindowLong(hWnd, Win32API.GWL_EXSTYLE, Win32API.WS_EX_NORMAL);
        }

        public void ArrangeAkariRate(bool isAllowZeroFirst = true) //変数のほうのあかり度を調整する。
        {
            int tempAkariRateInt = 0;
            string tempAkariRate = AkariRateTextBox.Text;
            for(int i=0,han='0',zen='０';i<10;++i) //全角の０～９を、半角の0～9にする。
            {
                tempAkariRate = tempAkariRate.Replace((char)(zen + i), (char)(han + i));
            }
            tempAkariRate = Regex.Replace(tempAkariRate, @"[^\d]", ""); //数値以外のゴミを消し去る。
            if (tempAkariRate.Length > 0) //文字(数値)が生き残ってたら
            {
                tempAkariRateInt = int.Parse(tempAkariRate);
                if (tempAkariRateInt > 100)
                {
                    tempAkariRateInt = 100;
                }
                else if (tempAkariRateInt < 0)
                {
                    tempAkariRateInt = 0;
                }
                akariRate = tempAkariRateInt;//あかり率の更新
                if ((tempAkariRate.Length == 2) && (tempAkariRate[0] == '0') && isAllowZeroFirst) //2文字で最大桁が0なら
                {
                    AkariRateTextBox.Text = tempAkariRate.ToString(); //｢00｣等を｢0｣と処理しないようにする。
                }
                else{
                    AkariRateTextBox.Text = akariRate.ToString(); //テキストの更新
                }
            }
            else //死んでたらからっぽにしとく。
            {
                AkariRateTextBox.Text = "";
            }
        }

        public void RenameAkariItem()
        {
            if ((RenameAkariTextBox.Text.Length>0)&&(AkariListBox.SelectedIndex>-1))
            {
                AkariListBox.Items[AkariListBox.SelectedIndex] = RenameAkariTextBox.Text;
            }
        }
        //** 色んな機能を詰め込んだものここまで **//


        //** ボタン操作関連 **//
        private void ReloadAllProcessButton_Click(object sender, EventArgs e)
        {
            ReloadAllProcessArray(); //配列データの更新
            ReloadAllProcessList(); //表示してるリストの更新
        }

        private void AddAkariListButton_Click(object sender, EventArgs e)
        {
            if (AllProcessListBox.SelectedIndex > -1) //なんらか物が選択されてたら
            {
                //重複をチェックしてから
                for (int i = 0; i < AkariListBox.Items.Count; ++i)
                {
                    if (AllProcessListBox.SelectedItem.ToString().IndexOf(AkariListBox.Items[i].ToString()) == 0)
                    {
                        return;
                    }
                }
                //そのプロセスを追加する。
                AkariListBox.Items.Add(AllProcessListBox.SelectedItem.ToString());
            }
        }

        private void DelAkariListButton_Click(object sender, EventArgs e)
        {
            if (AkariListBox.SelectedIndex > -1) //なんらか物が選択されてたら
            {
                AkariListBox.Items.RemoveAt(AkariListBox.SelectedIndex);
            }
        }

        private void ChangeAkariRateButton_Click(object sender, EventArgs e)
        {
            ArrangeAkariRate(false);
        }

        private void ChangeRenameAkariButton_Click(object sender, EventArgs e)
        {
            RenameAkariItem();
        }
        //** ボタン操作関連ここまで **//

        //** テキストボックス操作関連 **/
        private void AkariRateTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ArrangeAkariRate(false);
            }
        }

        private void AkariRateTextBox_TextChanged(object sender, EventArgs e)
        {
            ArrangeAkariRate();
        }

        private void AkariListBox_SelectedChanged(object sender, EventArgs e)
        {
            if (AkariListBox.SelectedIndex > -1) //なんらか物が選択されてたら
            {
                RenameAkariTextBox.Text = AkariListBox.SelectedItem.ToString();
            }
            else
            {
                RenameAkariTextBox.Text = "";
            }
        }

        private void RenameAkariTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                RenameAkariItem();
            }
        }
        //** テキストボックス操作関連ここまで **/

        //** タイマー関連 **/
        private void FastTimer_Tick(object sender, EventArgs e)
        {
            ChangeAlpha();
            if (hideFlag && this.Visible)
            {
                this.Visible = false;
                hideFlag = false;
            }
        }

        private void SlowTimer_Tick(object sender, EventArgs e)
        {
            ReloadAkariProcessArray();
        }
        //** タイマー関連ここまで**/

        //** メインフォーム関連 **/
        private void MainForm_Load(object sender, EventArgs e)
        {
            FileInfo fsp = new FileInfo(@"setting.ini");
            if (fsp.Exists) //あるときだけ読み込む。
            {
                int i = 0;
                string buff;
                StreamReader rfsp = fsp.OpenText();
                while ((buff = rfsp.ReadLine()) != null)
                {
                    if (i == 1)
                    {
                        if (buff.IndexOf("True") == 0)
                        {
                            isStartingDispCheckBox.Checked = true;
                            this.hideFlag = true;
                        }
                        else
                        {
                            isStartingDispCheckBox.Checked = false;
                            this.hideFlag = false;
                        }
                    }
                    else if (i == 3)
                    {
                        akariRate = int.Parse(buff);
                        AkariRateTextBox.Text = akariRate.ToString();
                    }
                    else if (i > 4)
                    {
                        AkariListBox.Items.Add(buff);
                    }
                    ++i;
                }
                rfsp.Close();
            }
            else //なければ作ればいいじゃない
            {
                fsp.Create();
            }
        }

        private void MainForm_Deactivate(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Visible = false;
            }

        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            FileInfo fsp = new FileInfo(@"setting.ini");
            StreamWriter wfsp = fsp.CreateText();
            wfsp.WriteLine("DEFAULT DISP");
            wfsp.WriteLine(isStartingDispCheckBox.Checked.ToString());
            wfsp.WriteLine("ALPHA");
            wfsp.WriteLine(akariRate.ToString());
            wfsp.WriteLine("PROCESS");
            for (int i = 0; i < AkariListBox.Items.Count; ++i)
            {
                wfsp.WriteLine(AkariListBox.Items[i].ToString());
            }
            wfsp.Close();
            ReloadAkariProcessArray();
            ChangeAlpha(false);
        }
        //** メインフォーム関連ここまで **/

        //** 常駐タスク関連 **//
        private void notifyIcon_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                this.Visible = !this.Visible;
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void 設定画面の表示ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Visible = true;
            this.WindowState = FormWindowState.Normal;
        }

        private void 閉じるToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //** 常駐タスク関連ここまで **//
    }

    public static class Win32API //Win32APIをつめただけの退屈なアレ
    {
        // ウィンドウタイトルを設定する Windows API 関数
        public delegate int EnumWindowsDelegate(IntPtr hWnd, int lParam);
        [DllImport("user32.dll")]
        public static extern int EnumWindows(EnumWindowsDelegate lpEnumFunc, int lParam);
        [DllImport("user32.dll")]
        public static extern int IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);
        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")]
        public static extern bool GetLayeredWindowAttributes(IntPtr hWnd, out int crKey, out byte Alpha, out int dwFlag);
        [DllImport("user32.dll")]
        public static extern bool SetLayeredWindowAttributes(IntPtr hWnd, int crKey, byte Alpha, int dwFlags);
        public const int GWL_EXSTYLE = -20;
        public const int GWL_STYLE = -16;
        public const int WS_EX_LAYERED = 0x00080000;
        public const int WS_EX_NORMAL  = 0x00000000;
        [DllImport("user32.dll")]
        public static extern long SetWindowLong(IntPtr hWnd, int index, int unValue); 
    }
}
