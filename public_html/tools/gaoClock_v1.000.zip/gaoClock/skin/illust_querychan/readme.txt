このスキンに利用したクエリちゃん（クエリ・ラヴクラフト）の画像は
こちらのサイトの利用ライセンスに従って利用しています。
http://www.query-chan.com/#dandd

これら画像を当作品以外で利用することはご遠慮ください。

http://www.query-chan.com/
2014 Copyright (C) POCKET QUERIES All Rights Reserved.



その他何かスキンに関して不具合や質問があれば、Twitterアカウント「@gaogao_9」まで。
名前　　　：がお
アカウント：https://twitter.com/gaogao_9
公開日　　：14/12/10
最終更新日：14/12/10
