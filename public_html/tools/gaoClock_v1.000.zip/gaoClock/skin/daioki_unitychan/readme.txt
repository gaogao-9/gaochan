このスキンでは、大沖さん(公式サイト：http://daioki.tumblr.com/)のイラストを使用しています。

このスキンに利用したユニティちゃん（大鳥こはく）は
こちらのサイトの利用ガイドラインに従って利用しています。
http://unity-chan.com/download/guideline.html

これら画像を当作品以外で利用することはご遠慮ください。

http://unity-chan.com/
Copyright (C)2013-2014 Unity Technologies Japan G.K. All Rights Reserved


その他何かスキンに関して不具合や質問があれば、Twitterアカウント「@gaogao_9」まで。
名前　　　：がお
アカウント：https://twitter.com/gaogao_9
公開日　　：14/12/10
最終更新日：14/12/10
