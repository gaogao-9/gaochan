﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ProcessAkkarin
{
    static class Program
    {
        /// ---------------------------------------------------------------------------
        /// <summary>
        ///    同名のプロセスが起動しているかどうかを示す値を返します。</summary>
        /// <returns>
        ///    同名のプロセスが起動中の場合は true。それ以外は false。</returns>
        /// ---------------------------------------------------------------------------
        public static bool PrevInstance()
        {
            // このアプリケーションのプロセス名を取得
            string stThisProcess = System.Diagnostics.Process.GetCurrentProcess().ProcessName;

            // 同名のプロセスが他に存在した場合は、既に起動していると判断する
            if (System.Diagnostics.Process.GetProcessesByName(stThisProcess).Length > 1)
            {
                return true;
            }

            // 存在しない場合は False を返す
            return false;
        }

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // 同名のプロセスが起動していない時は起動する
            if (!PrevInstance())
            {
                Application.Run(new MainForm());
            }
        }
    }
}
