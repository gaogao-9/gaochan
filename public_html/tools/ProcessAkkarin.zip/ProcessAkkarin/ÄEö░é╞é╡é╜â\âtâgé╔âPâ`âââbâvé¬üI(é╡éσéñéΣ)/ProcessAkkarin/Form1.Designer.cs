﻿namespace ProcessAkkarin
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ReloadAllProcessButton = new System.Windows.Forms.Button();
            this.AllProcessListBox = new System.Windows.Forms.ListBox();
            this.AddAkariListButton = new System.Windows.Forms.Button();
            this.DelAkariListButton = new System.Windows.Forms.Button();
            this.ChangeAkariRateButton = new System.Windows.Forms.Button();
            this.AkariRateTextBox = new System.Windows.Forms.TextBox();
            this.RenameAkariTextBox = new System.Windows.Forms.TextBox();
            this.ChangeRenameAkariButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.AkariListBox = new System.Windows.Forms.ListBox();
            this.isStartingDispCheckBox = new System.Windows.Forms.CheckBox();
            this.FastTimer = new System.Windows.Forms.Timer(this.components);
            this.SlowTimer = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.設定画面の表示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.閉じるToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ReloadAllProcessButton
            // 
            this.ReloadAllProcessButton.Location = new System.Drawing.Point(231, 12);
            this.ReloadAllProcessButton.Name = "ReloadAllProcessButton";
            this.ReloadAllProcessButton.Size = new System.Drawing.Size(37, 23);
            this.ReloadAllProcessButton.TabIndex = 0;
            this.ReloadAllProcessButton.Text = "更新";
            this.ReloadAllProcessButton.UseVisualStyleBackColor = true;
            this.ReloadAllProcessButton.Click += new System.EventHandler(this.ReloadAllProcessButton_Click);
            // 
            // AllProcessListBox
            // 
            this.AllProcessListBox.FormattingEnabled = true;
            this.AllProcessListBox.ItemHeight = 12;
            this.AllProcessListBox.Location = new System.Drawing.Point(12, 41);
            this.AllProcessListBox.Name = "AllProcessListBox";
            this.AllProcessListBox.Size = new System.Drawing.Size(256, 88);
            this.AllProcessListBox.TabIndex = 1;
            // 
            // AddAkariListButton
            // 
            this.AddAkariListButton.Location = new System.Drawing.Point(12, 135);
            this.AddAkariListButton.Name = "AddAkariListButton";
            this.AddAkariListButton.Size = new System.Drawing.Size(37, 23);
            this.AddAkariListButton.TabIndex = 2;
            this.AddAkariListButton.Text = "追加";
            this.AddAkariListButton.UseVisualStyleBackColor = true;
            this.AddAkariListButton.Click += new System.EventHandler(this.AddAkariListButton_Click);
            // 
            // DelAkariListButton
            // 
            this.DelAkariListButton.Location = new System.Drawing.Point(55, 135);
            this.DelAkariListButton.Name = "DelAkariListButton";
            this.DelAkariListButton.Size = new System.Drawing.Size(37, 23);
            this.DelAkariListButton.TabIndex = 3;
            this.DelAkariListButton.Text = "削除";
            this.DelAkariListButton.UseVisualStyleBackColor = true;
            this.DelAkariListButton.Click += new System.EventHandler(this.DelAkariListButton_Click);
            // 
            // ChangeAkariRateButton
            // 
            this.ChangeAkariRateButton.Location = new System.Drawing.Point(231, 135);
            this.ChangeAkariRateButton.Name = "ChangeAkariRateButton";
            this.ChangeAkariRateButton.Size = new System.Drawing.Size(37, 23);
            this.ChangeAkariRateButton.TabIndex = 4;
            this.ChangeAkariRateButton.Text = "変更";
            this.ChangeAkariRateButton.UseVisualStyleBackColor = true;
            this.ChangeAkariRateButton.Click += new System.EventHandler(this.ChangeAkariRateButton_Click);
            // 
            // AkariRateTextBox
            // 
            this.AkariRateTextBox.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.AkariRateTextBox.Location = new System.Drawing.Point(168, 135);
            this.AkariRateTextBox.Name = "AkariRateTextBox";
            this.AkariRateTextBox.Size = new System.Drawing.Size(32, 23);
            this.AkariRateTextBox.TabIndex = 6;
            this.AkariRateTextBox.TextChanged += new System.EventHandler(this.AkariRateTextBox_TextChanged);
            this.AkariRateTextBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.AkariRateTextBox_KeyUp);
            // 
            // RenameAkariTextBox
            // 
            this.RenameAkariTextBox.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.RenameAkariTextBox.Location = new System.Drawing.Point(12, 259);
            this.RenameAkariTextBox.Name = "RenameAkariTextBox";
            this.RenameAkariTextBox.Size = new System.Drawing.Size(213, 23);
            this.RenameAkariTextBox.TabIndex = 7;
            this.RenameAkariTextBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.RenameAkariTextBox_KeyUp);
            // 
            // ChangeRenameAkariButton
            // 
            this.ChangeRenameAkariButton.Location = new System.Drawing.Point(231, 259);
            this.ChangeRenameAkariButton.Name = "ChangeRenameAkariButton";
            this.ChangeRenameAkariButton.Size = new System.Drawing.Size(37, 23);
            this.ChangeRenameAkariButton.TabIndex = 8;
            this.ChangeRenameAkariButton.Text = "変更";
            this.ChangeRenameAkariButton.UseVisualStyleBackColor = true;
            this.ChangeRenameAkariButton.Click += new System.EventHandler(this.ChangeRenameAkariButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(98, 135);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(0, 4, 0, 4);
            this.label1.Size = new System.Drawing.Size(68, 23);
            this.label1.TabIndex = 9;
            this.label1.Text = "あかり度：";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(205, 135);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(0, 4, 0, 4);
            this.label2.Size = new System.Drawing.Size(23, 23);
            this.label2.TabIndex = 10;
            this.label2.Text = "％";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AkariListBox
            // 
            this.AkariListBox.FormattingEnabled = true;
            this.AkariListBox.ItemHeight = 12;
            this.AkariListBox.Location = new System.Drawing.Point(12, 165);
            this.AkariListBox.Name = "AkariListBox";
            this.AkariListBox.Size = new System.Drawing.Size(256, 88);
            this.AkariListBox.TabIndex = 5;
            this.AkariListBox.SelectedIndexChanged += new System.EventHandler(this.AkariListBox_SelectedChanged);
            this.AkariListBox.SelectedValueChanged += new System.EventHandler(this.AkariListBox_SelectedChanged);
            // 
            // isStartingDispCheckBox
            // 
            this.isStartingDispCheckBox.AutoSize = true;
            this.isStartingDispCheckBox.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.isStartingDispCheckBox.Location = new System.Drawing.Point(12, 12);
            this.isStartingDispCheckBox.Name = "isStartingDispCheckBox";
            this.isStartingDispCheckBox.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.isStartingDispCheckBox.Size = new System.Drawing.Size(132, 23);
            this.isStartingDispCheckBox.TabIndex = 11;
            this.isStartingDispCheckBox.Text = "起動時に表示しない";
            this.isStartingDispCheckBox.UseVisualStyleBackColor = true;
            // 
            // FastTimer
            // 
            this.FastTimer.Enabled = true;
            this.FastTimer.Interval = 50;
            this.FastTimer.Tick += new System.EventHandler(this.FastTimer_Tick);
            // 
            // SlowTimer
            // 
            this.SlowTimer.Enabled = true;
            this.SlowTimer.Interval = 1000;
            this.SlowTimer.Tick += new System.EventHandler(this.SlowTimer_Tick);
            // 
            // notifyIcon
            // 
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Text = "プロセス＼ｱｯｶﾘｰﾝ／";
            this.notifyIcon.Visible = true;
            this.notifyIcon.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon_MouseClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.設定画面の表示ToolStripMenuItem,
            this.閉じるToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(161, 70);
            // 
            // 設定画面の表示ToolStripMenuItem
            // 
            this.設定画面の表示ToolStripMenuItem.Name = "設定画面の表示ToolStripMenuItem";
            this.設定画面の表示ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.設定画面の表示ToolStripMenuItem.Text = "設定画面の表示";
            this.設定画面の表示ToolStripMenuItem.Click += new System.EventHandler(this.設定画面の表示ToolStripMenuItem_Click);
            // 
            // 閉じるToolStripMenuItem
            // 
            this.閉じるToolStripMenuItem.Name = "閉じるToolStripMenuItem";
            this.閉じるToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.閉じるToolStripMenuItem.Text = "閉じる";
            this.閉じるToolStripMenuItem.Click += new System.EventHandler(this.閉じるToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(280, 291);
            this.Controls.Add(this.isStartingDispCheckBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ChangeRenameAkariButton);
            this.Controls.Add(this.RenameAkariTextBox);
            this.Controls.Add(this.AkariRateTextBox);
            this.Controls.Add(this.AkariListBox);
            this.Controls.Add(this.ChangeAkariRateButton);
            this.Controls.Add(this.DelAkariListButton);
            this.Controls.Add(this.AddAkariListButton);
            this.Controls.Add(this.AllProcessListBox);
            this.Controls.Add(this.ReloadAllProcessButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "プロセス＼ｱｯｶﾘｰﾝ／";
            this.Deactivate += new System.EventHandler(this.MainForm_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ReloadAllProcessButton;
        private System.Windows.Forms.ListBox AllProcessListBox;
        private System.Windows.Forms.Button AddAkariListButton;
        private System.Windows.Forms.Button DelAkariListButton;
        private System.Windows.Forms.Button ChangeAkariRateButton;
        private System.Windows.Forms.TextBox AkariRateTextBox;
        private System.Windows.Forms.TextBox RenameAkariTextBox;
        private System.Windows.Forms.Button ChangeRenameAkariButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox AkariListBox;
        private System.Windows.Forms.CheckBox isStartingDispCheckBox;
        private System.Windows.Forms.Timer FastTimer;
        private System.Windows.Forms.Timer SlowTimer;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 設定画面の表示ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 閉じるToolStripMenuItem;
    }
}

