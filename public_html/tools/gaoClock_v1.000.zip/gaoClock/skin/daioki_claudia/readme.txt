このスキンでは、大沖さん(公式サイト：http://daioki.tumblr.com/)のイラストを使用しています。

このスキンに利用したクラウディア（クラウディア窓辺）の画像は
こちらのサイトの利用ガイドラインに従って利用しています。
http://msdn.microsoft.com/ja-jp/claudia00_03#02

また、以下のMicrosoft Azure キャラクター ライセンスに同意しています
http://msdn.microsoft.com/ja-jp/claudia00_03#06

これら画像を当作品以外で利用することはご遠慮ください。

http://msdn.microsoft.com/ja-jp/hh508969
(C) 2011 Microsoft Corporation All Rights Reserved



その他何かスキンに関して不具合や質問があれば、Twitterアカウント「@gaogao_9」まで。
名前　　　：がお
アカウント：https://twitter.com/gaogao_9
公開日　　：14/12/10
最終更新日：14/12/10
