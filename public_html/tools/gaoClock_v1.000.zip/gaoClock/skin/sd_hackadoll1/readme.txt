このスキンに利用したハッカドール1号の画像は
こちらの記事を参考に利用しています。
http://blog.hackadoll.com/post/100296829970

これら画像を当作品以外で利用することはご遠慮ください。

http://hackadoll.com/
copyright (C) DeNA Co., Ltd. All rights reserved.



その他何かスキンに関して不具合や質問があれば、Twitterアカウント「@gaogao_9」まで。
名前　　　：がお
アカウント：https://twitter.com/gaogao_9
公開日　　：14/12/10
最終更新日：14/12/10
