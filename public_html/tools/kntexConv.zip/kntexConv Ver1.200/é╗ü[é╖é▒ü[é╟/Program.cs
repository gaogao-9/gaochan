﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;

namespace kntexConv
{
	class Program
	{
		static List<string> logList = new List<string>();
		static void Main(string[] args)
		{
			string kuinTexPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
			kuinTexPath = kuinTexPath.Remove(kuinTexPath.LastIndexOf("kntexConv.exe")) + "KuinTex.exe";
			FileInfo kuinTexInfo = new FileInfo(kuinTexPath);
			if (!kuinTexInfo.Exists)
			{
				AddLog("KuinTex.exeが存在しません。");
				AddLog("kntexConv.exeをKuinTex.exeと同じディレクトリに入れてください。");
				AddLog("プログラムを終了します");
				Console.ReadKey();
				return;
			}

			if (args.Length != 1)
			{
				AddLog("使い方");
				AddLog("$ kntexConv 画像ファイル絶対パス(大体のフォーマットは読めます)");
				AddLog("これだけです。(席に戻ってやり直し)");
				AddLog("因みに、1コマンドで作れる画像は1枚だけです。ご了承ください。");
				AddLog("プログラムを終了します");
				Console.ReadKey();
				return;
			}
			else
			{
				FileInfo info = new FileInfo(args[0]);
				if (info.Exists)
				{
					try
					{
						Bitmap tmpBit = new Bitmap(info.FullName);
					}
					catch (Exception)
					{
						AddLog("画像データじゃないファイルが読まれたっぽいですよ、おにいさん。");
						AddLog("プログラムを終了します");
						Console.ReadKey();
						return;
					}
					bool wFlag = false;
					bool hFlag = false;
					Bitmap bImage = new Bitmap(info.FullName);
					Bitmap nImage;
					if ((bImage.Width == 0) || (bImage.Height == 0))
					{
						AddLog("画像サイズの縦幅もしくは横幅が0です");
						AddLog("プログラムを終了します");
						Console.ReadKey();
						return;
					}
					if ((bImage.Width & (bImage.Width - 1)) == 0)
					{
						wFlag = true;
					}
					if ((bImage.Height & (bImage.Height - 1)) == 0)
					{
						hFlag = true;
					}

					if (wFlag && hFlag)
					{
						AddLog("(注意!) サイズを変更する必要が無い画像みたいです");
						nImage = bImage;
					}
					else
					{
						AddLog("画像のサイズの変換を開始します");
						int wMax = bImage.Width;
						int hMax = bImage.Height;
						if (!wFlag)
						{
							wMax = RoundUpExp2(wMax);
						}
						if (!hFlag)
						{
							hMax = RoundUpExp2(hMax);
						}

						if (wMax > 4096 || hMax > 4096)
						{
							AddLog(info.Name + "を変換すると解像度が(" + wMax + "x" + hMax + ")になってしまいます！");
							AddLog("Kuinで使用できる画像サイズは、最大で(4096x4096)となっているので変換できません！");
							AddLog("プログラムを終了します");
							Console.ReadKey();
							return;
						}

						nImage = new Bitmap(wMax, hMax,System.Drawing.Imaging.PixelFormat.Format32bppArgb);

						int wClrPtr, hClrPtr;
						for (int i = 0, iLen = nImage.Width; i < iLen; ++i)
						{
							wClrPtr = (i < bImage.Width) ? i : bImage.Width - 1;
							for (int j = 0, jLen = nImage.Height; j < jLen; ++j)
							{
								hClrPtr = (j < bImage.Height) ? j : bImage.Height - 1;
								if (Bitmap.IsAlphaPixelFormat(bImage.PixelFormat))
								{
									nImage.SetPixel(i, j, bImage.GetPixel(wClrPtr, hClrPtr));
								}
								else
								{
									nImage.SetPixel(i, j, Color.FromArgb(255,bImage.GetPixel(wClrPtr, hClrPtr)));
								}

								if ((i * jLen + j) % 1250000 == 0)
								{
									AddLog("処理中...(" + (int)(100.0 * (i * jLen + j) / (iLen * jLen)) + "%)");
								}
							}
						}
						AddLog("処理が完了しました");
					}
					long unixTime = GetUnixTime(DateTime.Now);
					string tmpDPath = info.DirectoryName + @"\"+"tmp[" + unixTime.ToString() + "]";
					string outDPath = info.DirectoryName + @"\" + info.Name.Remove(info.Name.IndexOf('.')) + "[" + unixTime.ToString() + "]";
					DirectoryInfo dInfo = Directory.CreateDirectory(tmpDPath);
					AddLog("tmp[" + unixTime + "]というディレクトリを作成しました");
					string bImagePath = dInfo.FullName + @"\" + info.Name.Remove(info.Name.IndexOf('.')) + ".png.bak";
					string tmpImagePath = dInfo.FullName + @"\" + "tmp.png";
					string kntexPath = dInfo.FullName + @"\" + "tmp.png.kntex";
					bImage.Save(bImagePath, System.Drawing.Imaging.ImageFormat.Png);
					AddLog("画像のバックアップデータを保存しました");
					nImage.Save(tmpImagePath, System.Drawing.Imaging.ImageFormat.Png);
					AddLog("変換後の画像のデータをtmp.pngとして保存しました");

					AddLog(info.Name + "のサイズを(" + bImage.Width + "x" + bImage.Height + ")⇒(" + nImage.Width + "x" + nImage.Height + ")に変換しました");
					AddLog("kntexに変換します");

					ProcessStartInfo psInfo = new ProcessStartInfo();
					psInfo.FileName = "\"" + kuinTexPath + "\""; // 実行するファイル
					psInfo.Arguments = "\"" + tmpImagePath + "\"";
					psInfo.CreateNoWindow = false; // コンソール・ウィンドウを開かない
					psInfo.UseShellExecute = false; // シェル機能を使用しない
					psInfo.RedirectStandardInput = true;
					psInfo.RedirectStandardOutput = false;

					Process p = new Process();
					p.StartInfo = psInfo;
					p.Start(); // アプリの実行開始

					System.IO.StreamWriter sw = p.StandardInput;
					if (sw.BaseStream.CanWrite)
					{
						sw.WriteLine(@"");
					}

					p.WaitForExit();
					p.Close();

					FileInfo kntexInfo = new FileInfo(kntexPath);
					if (kntexInfo.Exists)
					{
						AddLog("kntexの作成に完了しました！");
					}
					else
					{
						AddLog("kntexの作成に失敗しました。");
						AddLog("プログラムを終了します");
						Console.ReadKey();
						return;
					}
					
					kntexInfo.MoveTo(dInfo.FullName + @"\" + info.Name.Remove(info.Name.IndexOf('.')) + ".kntex");
					AddLog("tmp.png.kntexを" + info.Name.Remove(info.Name.IndexOf('.')) + ".kntexに名前変更をしました");

					FileInfo tmpInfo = new FileInfo(tmpImagePath);
					tmpInfo.MoveTo(dInfo.FullName + @"\" + info.Name.Remove(info.Name.IndexOf('.')) + ".png");
					AddLog("tmp.pngを" + info.Name.Remove(info.Name.IndexOf('.')) + ".pngに名前変更をしました");

					DirectoryInfo tmpDInfo = new DirectoryInfo(tmpDPath);
					tmpDInfo.MoveTo(outDPath);
					AddLog("ディレクトリ:tmp[" + unixTime + "]を" + info.Name.Remove(info.Name.IndexOf('.')) + "[" + unixTime + "]に変更しました");

					AddLog("全工程が完了しました！");
					MakeLogFile(outDPath + @"\" + "log.txt");

					Console.WriteLine("プログラムを終了します。何かキーを入力してください");
					Console.ReadKey();
				}
				else
				{
					Console.WriteLine(args[0] + "は存在しないファイルパスっぽいですね～");
					AddLog("プログラムを終了します");
					Console.ReadKey();
				}
			}
		}

		// UNIXエポックを表すDateTimeオブジェクトを取得
		private static DateTime UNIX_EPOCH = new DateTime(1970, 1, 1, 0, 0, 0, 0);
		public static long GetUnixTime(DateTime targetTime)
		{
			// UTC時間に変換
			targetTime = targetTime.ToUniversalTime();

			// UNIXエポックからの経過時間を取得
			TimeSpan elapsedTime = targetTime - UNIX_EPOCH;

			// 経過秒数に変換
			return (long)elapsedTime.TotalSeconds;
		}
		public static int RoundUpExp2(int x)
		{
			if (x <= 0) return 0;
			if (x == 1) return 1;
			x -= 1;
			int r = 1;
			while ((x /= 2) >= 1) r *= 2;
			return r * 2;
		}
		public static void AddLog(string mes)
		{
			logList.Add(mes);
			Console.WriteLine(mes);
		}
		public static void MakeLogFile(string path)
		{
			FileInfo logInfo = new FileInfo(path);
			StreamWriter swlog = logInfo.CreateText();
			for (int i = 0, iLen = logList.Count; i < iLen; ++i)
			{
				swlog.WriteLine(logList[i]);
			}
			swlog.Close();
			swlog.Dispose();
			Console.WriteLine("{0}の出力が完了しました！",logInfo.Name);
		}
	}
}
